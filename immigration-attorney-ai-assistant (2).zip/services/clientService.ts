
// This is a placeholder for a service that would manage client profiles.
// In a real application, this would interact with a database or a CRM API.

export interface ClientProfile {
  id: string;
  name: string;
  caseType: string;
  status: string;
}

const DUMMY_CLIENTS: ClientProfile[] = [
  { id: '1', name: 'John Doe', caseType: 'H-1B Visa', status: 'Pending RFE' },
  { id: '2', name: 'Jane Smith', caseType: 'Asylum Application', status: 'Interview Scheduled' },
];

export const getClients = async (): Promise<ClientProfile[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  return DUMMY_CLIENTS;
};

export const getClientById = async (id: string): Promise<ClientProfile | undefined> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 300));
    return DUMMY_CLIENTS.find(client => client.id === id);
};
