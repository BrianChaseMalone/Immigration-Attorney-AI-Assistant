import { GoogleGenAI, GenerateContentResponse, GenerateContentParameters } from "@google/genai";
import { GroundingMetadata } from '../types';

const getAI = () => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set. Please select one from the 'Run settings' menu.");
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
}

export interface GeminiResult {
  text: string;
  groundingMetadata?: GroundingMetadata;
}

const processResponse = (response: GenerateContentResponse): GeminiResult => {
    return {
        text: response.text,
        groundingMetadata: response.candidates?.[0]?.groundingMetadata as GroundingMetadata | undefined,
    };
};

const callGemini = async (params: GenerateContentParameters): Promise<GeminiResult> => {
    const ai = getAI();
    const response = await ai.models.generateContent(params);
    return processResponse(response);
};

export const summarizeText = async (text: string): Promise<GeminiResult> => {
  return callGemini({
    model: 'gemini-2.5-flash',
    contents: `Summarize the following legal document concisely for an immigration attorney, highlighting key facts, dates, and legal arguments: ${text}`,
  });
};

export const draftIntakeForm = async (caseType: string): Promise<GeminiResult> => {
  return callGemini({
    model: 'gemini-2.5-flash',
    contents: `Generate a comprehensive, fillable client intake form as a single HTML file for an immigration case concerning: "${caseType}".
The HTML should be well-structured with <form>, <label>, <input type="text">, <input type="date">, <input type="email">, and <textarea> tags.
Use <fieldset> and <legend> to group questions into logical sections: Personal Information, Immigration History, Family Details, Employment, and specific questions relevant to this case type.
Include a section for "Supporting Documents" that lists common documents needed.
Add a <style> block in the <head> for clean, professional, and responsive styling. Ensure the form is easy to read and use.
The entire output must be only the raw HTML code, starting with <!DOCTYPE html>.`,
  });
};

export const getVisaInfo = async (query: string): Promise<GeminiResult> => {
  return callGemini({
    model: 'gemini-2.5-flash',
    contents: `As an expert immigration law assistant, provide up-to-date information on the following topic: ${query}. Cite your sources.`,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });
};

export const performLegalResearch = async (query: string): Promise<GeminiResult> => {
  return callGemini({
    model: 'gemini-2.5-pro',
    contents: `Perform in-depth legal research on the following complex immigration law query. Provide a detailed analysis, cite relevant statutes, regulations, and precedent cases. Query: ${query}`,
    config: {
      thinkingConfig: { thinkingBudget: 32768 },
    },
  });
};

export const findLocalServices = async (query: string, location: { latitude: number; longitude: number } | string): Promise<GeminiResult> => {
  if (typeof location === 'string') {
    return callGemini({
      model: 'gemini-2.5-flash',
      contents: `Find the following services for an immigrant client near ${location}: ${query}. Provide addresses and contact information where available.`,
       config: {
         tools: [{ googleSearch: {} }],
       }
    });
  } else {
    return callGemini({
      model: 'gemini-2.5-flash',
      contents: `Find the following services for an immigrant client near my current location: ${query}`,
      config: {
        tools: [{ googleMaps: {} }],
        toolConfig: {
          retrievalConfig: {
            latLng: location,
          },
        },
      },
    });
  }
};

export const generateClientAdvisal = async (details: {
  clientName: string;
  caseType: string;
  currentStage: string;
  nextStage: string;
  deadlines: string;
  concerns: string;
}): Promise<GeminiResult> => {
  const prompt = `Generate a professional and empathetic client advisal for an immigration case.
  Client Name: ${details.clientName || 'Valued Client'}
  Case Type: ${details.caseType}
  Current Stage: ${details.currentStage}
  Next Stage: ${details.nextStage}
  Important Deadlines: ${details.deadlines || 'None specified'}
  Specific Concerns to Address: ${details.concerns || 'None specified'}

  The advisal should be in Markdown format and include:
  1. A clear summary of the current case status.
  2. A detailed explanation of the next stage (${details.nextStage}).
  3. What is expected of the client for this next stage.
  4. A list of documents they need to provide, including any specified deadlines.
  5. A concluding paragraph that offers reassurance, manages expectations by stating that no outcome is guaranteed, and explains how their cooperation helps in building the strongest possible case.
  Address the client directly and maintain a supportive tone.`;

  return callGemini({
    model: 'gemini-2.5-flash',
    contents: prompt,
  });
};

export const generateDocumentChecklist = async (caseType: string): Promise<GeminiResult> => {
  const prompt = `Generate a comprehensive document checklist in Markdown format for an immigration case: "${caseType}".
  Organize the checklist into logical sections, such as:
  - Documents from the Petitioner
  - Documents from the Beneficiary (Applicant)
  - Joint Documents (if applicable)
  For each document, provide a brief description of what is required (e.g., "Full birth certificate showing parents' names").
  Include common required forms by name and number (e.g., Form I-130, Form G-325A).`;

  return callGemini({
    model: 'gemini-2.5-flash',
    contents: prompt,
  });
};

export const generateCorroboratingEvidenceList = async (declaration: string): Promise<GeminiResult> => {
    const prompt = `You are an expert AI assistant for an immigration attorney specializing in asylum law. Your task is to analyze the provided personal declaration from an asylum applicant and generate a comprehensive list of potential corroborating evidence to strengthen their case.

The declaration is as follows:
---
${declaration}
---

Based on the facts presented in the declaration, provide a detailed and organized list in Markdown format covering the following three sections:

### 1. Supporting and Corroborating Documents
Create a checklist of specific documents the applicant should try to gather. For each item, briefly explain why it's relevant. Examples include:
- Identity documents (passports, birth certificates).
- Medical records, psychological evaluations, or photos of injuries if physical or psychological harm is mentioned.
- Police reports or court documents related to incidents described.
- Threatening letters, emails, or social media messages.
- Proof of membership in any organization mentioned (political party, religious group, etc.).
- Country condition reports from reputable sources (e.g., Human Rights Watch, Amnesty International, U.S. Department of State) that corroborate the general situation described.

### 2. Potential Personal Witness Affidavits
Identify individuals mentioned or implied in the declaration who could provide a sworn affidavit. For each potential witness, describe what specific facts or events from the declaration they could corroborate.
- Example: "Family Member [Name/Relationship]: Can attest to the applicant's fear after the incident on [Date] and the changes in their behavior."
- Example: "Co-worker/Friend [Name]: Can confirm the applicant's involvement in the political rally and the threats received afterward."

### 3. Suggested Expert Witness Declarations
Suggest specific types of expert witnesses whose declarations could significantly bolster the claim. For each suggested expert, explain how their testimony would help establish the applicant's credibility and, most importantly, strengthen the nexus between the harm feared and one of the five protected grounds for asylum (race, religion, nationality, membership in a particular social group, or political opinion).
- Example: "Expert on Country Conditions in [Country/Region]: A declaration from this expert could confirm that the type of persecution described is common for individuals with the applicant's political profile, thus strengthening the nexus to a political opinion claim."
- Example: "Forensic Medical Examiner or Psychologist: If the applicant claims torture or severe trauma, an expert can evaluate them and provide an opinion on whether their physical scars or psychological symptoms (like PTSD) are consistent with their testimony. This powerfully corroborates their credibility."`;

    return callGemini({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: {
          thinkingConfig: { thinkingBudget: 32768 },
        },
    });
};

export const getDeclarationFeedback = async (declaration: string): Promise<GeminiResult> => {
    const prompt = `You are an expert AI legal assistant for an immigration attorney. Your purpose is to review a client's draft personal declaration for an asylum claim and provide constructive, empathetic feedback to help them improve it.

The goal is to elicit more detail to make their story vivid, credible, and compelling for an immigration judge. Do NOT rewrite their story. Instead, provide supportive feedback and a list of specific follow-up questions.

The client's draft declaration is:
---
${declaration}
---

Please provide your feedback in Markdown format with the following structure:

1.  **Positive Opening:** Start with an encouraging and empathetic sentence acknowledging the difficulty of sharing their story and thanking them for their draft.
2.  **The Importance of Details:** Briefly explain in one or two sentences why specific details (like dates, names, and locations) are so important for making their declaration strong and believable to the judge.
3.  **Follow-Up Questions:** This should be the main section. Go through their declaration and identify areas that could be more detailed. Phrase your feedback as gentle, guiding questions. Group your questions under headings that correspond to the events or paragraphs in their story.

    Focus on asking for:
    - **Specific Dates & Times:** Instead of "one day," ask "Can you remember the exact date this happened? If not, what month and year was it? What time of day?"
    - **Specific Names:** "You mentioned 'a man threatened you.' Did you know his name? If not, what did he look like? What was he wearing?"
    - **Specific Locations:** "You said you were at a protest. Where exactly was this protest held? What was the name of the street or the square? What buildings were nearby?"
    - **Sensory Details:** "When you were hiding, what could you hear? What did the room smell like?"
    - **Direct Quotes:** "You wrote that they shouted threats. Can you remember the exact words they used?"
    - **Emotional Impact:** "How did you feel in that exact moment? What were you thinking?"
4.  **Encouraging Closing:** End with a positive and supportive statement, encouraging them that these details will make their final declaration much stronger.`;

    return callGemini({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: {
          thinkingConfig: { thinkingBudget: 32768 },
        },
    });
};

export const generateCollaborativeResponse = async (caseManagerNote: string, attorneyContext: string): Promise<GeminiResult> => {
    const prompt = `
You are an AI communication coach for a lead immigration attorney who is mentoring their case managers. Your goal is to help the attorney draft responses that are collaborative, constructive, and foster a strong, trusting team environment.

The attorney wants to lead by example, validate their team's work, and gently guide them on matters like prioritization and procedure. The tone should always be supportive and focused on shared goals and client success. Avoid a bossy or dismissive tone.

Here is the note from the case manager:
---
${caseManagerNote}
---

Here is the additional context and desired outcome from the attorney:
---
${attorneyContext}
---

Please draft a response from the attorney to the case manager that incorporates the following principles:

1.  **Acknowledge & Validate:** Start by acknowledging the case manager's message and validating their concerns or the urgency they feel. Show you've heard them.
2.  **Collaborative Framing:** Use "we," "us," and "our" to frame the situation as a team effort.
3.  **Explain the 'Why':** If you need to redirect, delegate, or change priority, clearly explain the reasoning. Connect it back to the case strategy, client's best interest, or overall workflow efficiency. This is a teaching moment.
4.  **Provide a Clear Path Forward:** State the next action step clearly. What should the case manager do? What will you do?
5.  **Lead with Accountability (If Applicable):** If the attorney's context mentions a mistake they made, incorporate a brief, professional acknowledgment of their role. This models the behavior they want to see.
6.  **End with Encouragement:** Conclude on a positive, forward-looking note that reinforces your confidence in the case manager and the team.

The final output should be only the drafted email/message text, ready for the attorney to copy, edit, and send.
`;

    return callGemini({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: {
          thinkingConfig: { thinkingBudget: 24576 },
        },
    });
};