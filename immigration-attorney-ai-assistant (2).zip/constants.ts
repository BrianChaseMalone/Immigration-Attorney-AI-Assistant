import React from 'react';
import {
    DocumentTextIcon,
    DocumentPlusIcon,
    GlobeAltIcon,
    ScaleIcon,
    MapPinIcon,
    ChatBubbleBottomCenterTextIcon,
    ClipboardDocumentCheckIcon,
    MagnifyingGlassPlusIcon,
    PencilSquareIcon,
    UserGroupIcon,
} from './components/Icons';
import { ToolId } from './types';

export interface ToolInfo {
    id: ToolId;
    name: string;
    description: string;
    icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
}

export const TOOLS: ToolInfo[] = [
    {
        id: 'summarizer',
        name: 'Case Brief Summarizer',
        description: 'Summarize legal documents',
        icon: DocumentTextIcon,
    },
    {
        id: 'intake-form-drafter',
        name: 'Intake Form Drafter',
        description: 'Generate client intake forms',
        icon: DocumentPlusIcon,
    },
    {
        id: 'visa-info-hub',
        name: 'Visa Information Hub',
        description: 'Get up-to-date visa info',
        icon: GlobeAltIcon,
    },
    {
        id: 'legal-research',
        name: 'Legal Research Assistant',
        description: 'In-depth legal analysis',
        icon: ScaleIcon,
    },
    {
        id: 'declaration-feedback-assistant',
        name: 'Declaration Feedback',
        description: 'Get feedback on a declaration',
        icon: PencilSquareIcon,
    },
    {
        id: 'corroborating-evidence-advisor',
        name: 'Evidence Advisor',
        description: 'Get evidence ideas for a case',
        icon: MagnifyingGlassPlusIcon,
    },
    {
        id: 'collaborative-response-generator',
        name: 'Collaborative Response',
        description: 'Draft responses to team members',
        icon: UserGroupIcon,
    },
    {
        id: 'local-services',
        name: 'Find Local Services',
        description: 'Locate services for clients',
        icon: MapPinIcon,
    },
    {
        id: 'client-advisal',
        name: 'Client Advisal Generator',
        description: 'Draft client status updates',
        icon: ChatBubbleBottomCenterTextIcon,
    },
    {
        id: 'doc-checklist',
        name: 'Document Checklist',
        description: 'Create case checklists',
        icon: ClipboardDocumentCheckIcon,
    },
];