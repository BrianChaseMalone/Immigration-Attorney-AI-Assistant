import React, { useState, lazy, Suspense } from 'react';
import { Sidebar } from './components/Sidebar';
import { Welcome } from './components/Welcome';
import { ToolId } from './types';
import { LoadingSpinner } from './components/LoadingSpinner';

const Summarizer = lazy(() => import('./components/Summarizer'));
const IntakeFormDrafter = lazy(() => import('./components/IntakeFormDrafter'));
const VisaInfoHub = lazy(() => import('./components/VisaInfoHub'));
const LegalResearchAssistant = lazy(() => import('./components/LegalResearchAssistant'));
const LocalServicesFinder = lazy(() => import('./components/LocalServicesFinder'));
const ClientAdvisalGenerator = lazy(() => import('./components/ClientAdvisalGenerator'));
const DocumentChecklistGenerator = lazy(() => import('./components/DocumentChecklistGenerator'));
const CorroboratingEvidenceAdvisor = lazy(() => import('./components/CorroboratingEvidenceAdvisor'));
const DeclarationFeedbackAssistant = lazy(() => import('./components/DeclarationFeedbackAssistant'));
const CollaborativeResponseGenerator = lazy(() => import('./components/CollaborativeResponseGenerator'));


const TOOL_COMPONENTS: { [key in ToolId]: React.ComponentType } = {
  'summarizer': Summarizer,
  'intake-form-drafter': IntakeFormDrafter,
  'visa-info-hub': VisaInfoHub,
  'legal-research': LegalResearchAssistant,
  'local-services': LocalServicesFinder,
  'client-advisal': ClientAdvisalGenerator,
  'doc-checklist': DocumentChecklistGenerator,
  'corroborating-evidence-advisor': CorroboratingEvidenceAdvisor,
  'declaration-feedback-assistant': DeclarationFeedbackAssistant,
  'collaborative-response-generator': CollaborativeResponseGenerator,
};

const App: React.FC = () => {
  const [activeTool, setActiveTool] = useState<ToolId | null>(null);

  const handleSelectTool = (toolId: ToolId) => {
    setActiveTool(toolId);
  };

  const ActiveComponent = activeTool ? TOOL_COMPONENTS[activeTool] : null;

  return (
    <div className="flex h-screen bg-slate-100 dark:bg-slate-900/50 font-sans">
      <Sidebar activeTool={activeTool} onSelectTool={handleSelectTool} />
      <main className="flex-1 p-6 sm:p-8 overflow-y-auto">
        <Suspense fallback={<div className="flex items-center justify-center h-full"><LoadingSpinner /></div>}>
            {ActiveComponent ? <ActiveComponent /> : <Welcome />}
        </Suspense>
      </main>
    </div>
  );
};

export default App;