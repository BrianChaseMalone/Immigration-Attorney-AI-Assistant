import React, { useState } from 'react';
import { ToolContainer } from './ToolContainer';
import { DocumentPlusIcon, PaperAirplaneIcon, InformationCircleIcon } from './Icons';
import { draftIntakeForm, GeminiResult } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import { GroundingSources } from './GroundingSources';

const IntakeFormDrafter: React.FC = () => {
  const [caseType, setCaseType] = useState('');
  const [result, setResult] = useState<GeminiResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copySuccess, setCopySuccess] = useState('');

  const handleCopyToClipboard = () => {
    if (result) {
      navigator.clipboard.writeText(result.text).then(() => {
        setCopySuccess('Copied!');
        setTimeout(() => setCopySuccess(''), 2000);
      }, () => {
        setCopySuccess('Failed to copy.');
        setTimeout(() => setCopySuccess(''), 2000);
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!caseType.trim()) return;

    setIsLoading(true);
    setResult(null);
    setError(null);

    try {
      const response = await draftIntakeForm(caseType);
      // Clean the response to ensure it's valid HTML
      const cleanedResponse = response.text.replace(/^```html\n|```$/g, '').trim();
      setResult({ ...response, text: cleanedResponse });
    } catch (err) {
      setError('An error occurred while drafting the form. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ToolContainer
      title="Client Intake Form Drafter"
      description="Generate a fillable HTML intake form to email to your clients."
      icon={DocumentPlusIcon}
    >
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
        <input
          type="text"
          value={caseType}
          onChange={(e) => setCaseType(e.target.value)}
          placeholder="e.g., Asylum Application, H-1B Visa, Family-based Green Card"
          className="flex-grow p-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !caseType.trim()}
          className="flex items-center justify-center gap-2 bg-indigo-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-indigo-700 disabled:bg-indigo-300 dark:disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors shadow flex-shrink-0"
        >
           <PaperAirplaneIcon className="w-5 h-5"/>
          Draft Form
        </button>
      </form>
      {isLoading && <LoadingSpinner />}
      {error && <div className="mt-4 text-center text-red-500 bg-red-100 dark:bg-red-900/50 p-3 rounded-lg">{error}</div>}
      {result && (
        <div className="mt-6 space-y-6">
          <div className="flex items-start gap-4 bg-emerald-50 dark:bg-emerald-900/40 p-4 rounded-lg border border-emerald-200 dark:border-emerald-800">
            <InformationCircleIcon className="w-6 h-6 text-emerald-500 dark:text-emerald-400 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-emerald-800 dark:text-emerald-200">How to Use Your Generated Form</h3>
              <ol className="list-decimal list-inside text-sm text-emerald-700 dark:text-emerald-300 mt-2 space-y-1">
                <li>Click the <strong>"Copy HTML"</strong> button next to the code below.</li>
                <li>Open a plain text editor (like Notepad on Windows or TextEdit on Mac).</li>
                <li>Paste the copied code into a new, blank file.</li>
                <li>Save the file with an <strong>.html</strong> extension (e.g., <code>intake_form.html</code>).</li>
                <li>Attach this new .html file to an email and send it to your client.</li>
              </ol>
              <p className="text-xs text-emerald-600 dark:text-emerald-400 mt-3">
                Your client can open this file in any web browser, fill out the form, and then use the browser's "Print" function to save it as a PDF to send back to you.
              </p>
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">Generated Form HTML</h3>
              <button
                onClick={handleCopyToClipboard}
                className="bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold py-1 px-3 rounded-md hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors"
              >
                {copySuccess || 'Copy HTML'}
              </button>
            </div>
            <textarea
              readOnly
              value={result.text}
              className="w-full h-64 p-3 font-mono text-sm border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition"
              aria-label="Generated Form HTML"
            />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100 mb-2">Form Preview</h3>
            <div className="border border-slate-300 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-200">
               <iframe 
                  srcDoc={result.text}
                  title="Form Preview"
                  className="w-full h-[32rem] border-none rounded-lg"
                  sandbox="allow-forms"
               />
            </div>
            <GroundingSources metadata={result.groundingMetadata} />
          </div>
        </div>
      )}
    </ToolContainer>
  );
};

export default IntakeFormDrafter;