import React, { useState } from 'react';
import { ToolContainer } from './ToolContainer';
import { UserGroupIcon, PaperAirplaneIcon } from './Icons';
import { generateCollaborativeResponse, GeminiResult } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import AutoGrowingTextarea from './AutoGrowingTextarea';

const CollaborativeResponseGenerator: React.FC = () => {
  const [caseManagerNote, setCaseManagerNote] = useState('');
  const [attorneyContext, setAttorneyContext] = useState('');
  const [result, setResult] = useState<GeminiResult | null>(null);
  const [editableResponse, setEditableResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copySuccess, setCopySuccess] = useState('');

  const handleCopyToClipboard = () => {
    if (editableResponse) {
      navigator.clipboard.writeText(editableResponse).then(() => {
        setCopySuccess('Copied!');
        setTimeout(() => setCopySuccess(''), 2000);
      }, () => {
        setCopySuccess('Failed to copy.');
        setTimeout(() => setCopySuccess(''), 2000);
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!caseManagerNote.trim() || !attorneyContext.trim()) return;

    setIsLoading(true);
    setResult(null);
    setError(null);

    try {
      const response = await generateCollaborativeResponse(caseManagerNote, attorneyContext);
      setResult(response);
      setEditableResponse(response.text);
    } catch (err) {
      setError('An error occurred while generating the response. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const isFormIncomplete = !caseManagerNote.trim() || !attorneyContext.trim();

  return (
    <ToolContainer
      title="Collaborative Response Generator"
      description="Draft constructive, team-building responses to your case managers."
      icon={UserGroupIcon}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="caseManagerNote" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Case Manager's Note/Email *</label>
          <AutoGrowingTextarea
            id="caseManagerNote"
            value={caseManagerNote}
            onChange={(e) => setCaseManagerNote(e.target.value)}
            placeholder="Paste the message from your case manager here..."
            className="w-full min-h-[8rem] p-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition"
            disabled={isLoading}
            required
          />
        </div>
        <div>
          <label htmlFor="attorneyContext" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Your Private Context & Goal *</label>
          <AutoGrowingTextarea
            id="attorneyContext"
            value={attorneyContext}
            onChange={(e) => setAttorneyContext(e.target.value)}
            placeholder="e.g., 'I need to delay this client meeting. Explain that we need the signed G-28 first to be effective.' OR 'This is the third time they've asked for this. Gently remind them of our prioritization process.' OR 'I made a mistake here; I need to own it and clarify the correct procedure.'"
            className="w-full min-h-[8rem] p-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition"
            disabled={isLoading}
            required
          />
        </div>
        <button
          type="submit"
          disabled={isLoading || isFormIncomplete}
          className="w-full flex items-center justify-center gap-2 bg-indigo-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-indigo-700 disabled:bg-indigo-300 dark:disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors shadow"
        >
          <PaperAirplaneIcon className="w-5 h-5"/>
          Generate Response
        </button>
      </form>
      {isLoading && <LoadingSpinner />}
      {error && <div className="mt-4 text-center text-red-500 bg-red-100 dark:bg-red-900/50 p-3 rounded-lg">{error}</div>}
      {result && (
        <div className="mt-6">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">Drafted Response (Editable)</h3>
              <button
                onClick={handleCopyToClipboard}
                className="bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold py-1 px-3 rounded-md hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors"
              >
                {copySuccess || 'Copy Text'}
              </button>
            </div>
            <AutoGrowingTextarea
                value={editableResponse}
                onChange={(e) => setEditableResponse(e.target.value)}
                className="w-full min-h-[16rem] p-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition"
            />
        </div>
      )}
    </ToolContainer>
  );
};

export default CollaborativeResponseGenerator;