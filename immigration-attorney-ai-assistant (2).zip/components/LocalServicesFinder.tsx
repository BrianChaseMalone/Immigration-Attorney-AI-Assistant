import React, { useState } from 'react';
import { ToolContainer } from './ToolContainer';
import { MapPinIcon, PaperAirplaneIcon, InformationCircleIcon } from './Icons';
import { findLocalServices, GeminiResult } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import { GroundingSources } from './GroundingSources';

type LocationMode = 'auto' | 'manual';

const LocalServicesFinder: React.FC = () => {
  const [query, setQuery] = useState('');
  const [manualLocation, setManualLocation] = useState('');
  const [result, setResult] = useState<GeminiResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [locationMode, setLocationMode] = useState<LocationMode>('auto');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setResult(null);
    setError(null);
    
    if (locationMode === 'manual') {
      if (!manualLocation.trim()) {
        setError("Please enter a location to search.");
        setIsLoading(false);
        return;
      }
      fetchServices(manualLocation);
    } else {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          fetchServices({ latitude, longitude });
        },
        (geoError) => {
          setError(`Geolocation failed: ${geoError.message}. Please enter a location manually.`);
          setLocationMode('manual');
          setIsLoading(false);
        }
      );
    }
  };
  
  const fetchServices = async (location: { latitude: number; longitude: number; } | string) => {
    try {
      const response = await findLocalServices(query, location);
      setResult(response);
    } catch (err) {
      setError('An error occurred while finding services. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <ToolContainer
      title="Find Local Services"
      description="Locate nearby services for your clients, such as USCIS offices or translation services."
      icon={MapPinIcon}
    >
      {locationMode === 'auto' && (
        <div className="flex items-start gap-3 bg-amber-50 dark:bg-amber-900/40 p-4 rounded-lg mb-6 border border-amber-200 dark:border-amber-800">
            <InformationCircleIcon className="w-5 h-5 text-amber-500 dark:text-amber-400 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-amber-700 dark:text-amber-300">
                This tool will request access to your location to find nearby services. If you deny, you can enter a location manually.
            </p>
        </div>
      )}
      <form onSubmit={handleSubmit} className="space-y-3">
        {locationMode === 'manual' && (
            <div>
                 <label htmlFor="manualLocation" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Location</label>
                 <input
                    id="manualLocation"
                    type="text"
                    value={manualLocation}
                    onChange={(e) => setManualLocation(e.target.value)}
                    placeholder="e.g., 'Brooklyn, NY' or a specific address"
                    className="w-full p-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition"
                    disabled={isLoading}
                  />
            </div>
        )}
        <div className="flex flex-col sm:flex-row gap-3">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g., 'certified translators', 'USCIS Application Support Center'"
              className="flex-grow p-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={isLoading || !query.trim()}
              className="flex items-center justify-center gap-2 bg-indigo-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-indigo-700 disabled:bg-indigo-300 dark:disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors shadow flex-shrink-0"
            >
               <PaperAirplaneIcon className="w-5 h-5"/>
              Find Services
            </button>
        </div>
      </form>
      {isLoading && <LoadingSpinner />}
      {error && <div className="mt-4 text-center text-red-500 bg-red-100 dark:bg-red-900/50 p-3 rounded-lg">{error}</div>}
      {result && (
        <div className="mt-6 prose prose-slate dark:prose-invert max-w-none prose-p:my-2 prose-headings:my-3">
          <div dangerouslySetInnerHTML={{ __html: (window as any).marked.parse(result.text) }} />
          <GroundingSources metadata={result.groundingMetadata} />
        </div>
      )}
    </ToolContainer>
  );
};

export default LocalServicesFinder;