
import React from 'react';
import { GroundingMetadata } from '../types';
import { LinkIcon, MapIcon } from './Icons';

interface GroundingSourcesProps {
  metadata?: GroundingMetadata;
}

export const GroundingSources: React.FC<GroundingSourcesProps> = ({ metadata }) => {
  if (!metadata || !metadata.groundingChunks || metadata.groundingChunks.length === 0) {
    return null;
  }

  return (
    <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-700">
      <h4 className="text-sm font-semibold text-slate-600 dark:text-slate-400 mb-3">Sources:</h4>
      <div className="flex flex-wrap gap-3">
        {metadata.groundingChunks.map((chunk, index) => {
          if (chunk.web) {
            return (
              <a
                key={`web-${index}`}
                href={chunk.web.uri}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 text-xs px-3 py-1.5 rounded-full transition-colors"
              >
                <LinkIcon className="w-4 h-4" />
                <span>{chunk.web.title || new URL(chunk.web.uri).hostname}</span>
              </a>
            );
          }
          if (chunk.maps) {
            return (
               <a
                key={`maps-${index}`}
                href={chunk.maps.uri}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 bg-emerald-100 dark:bg-emerald-900/50 hover:bg-emerald-200 dark:hover:bg-emerald-800/50 text-emerald-700 dark:text-emerald-300 text-xs px-3 py-1.5 rounded-full transition-colors"
              >
                <MapIcon className="w-4 h-4" />
                <span>{chunk.maps.title || 'View on Google Maps'}</span>
              </a>
            )
          }
          return null;
        })}
      </div>
    </div>
  );
};
