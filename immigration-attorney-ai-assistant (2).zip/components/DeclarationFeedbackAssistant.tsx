import React, { useState } from 'react';
import { ToolContainer } from './ToolContainer';
import { PencilSquareIcon, LightBulbIcon, PaperAirplaneIcon } from './Icons';
import { getDeclarationFeedback, GeminiResult } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import { GroundingSources } from './GroundingSources';
import AutoGrowingTextarea from './AutoGrowingTextarea';

const DeclarationFeedbackAssistant: React.FC = () => {
  const [declaration, setDeclaration] = useState('');
  const [result, setResult] = useState<GeminiResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!declaration.trim()) return;

    setIsLoading(true);
    setResult(null);
    setError(null);

    try {
      const response = await getDeclarationFeedback(declaration);
      setResult(response);
    } catch (err) {
      setError('An error occurred while generating feedback. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ToolContainer
      title="Declaration Feedback Assistant"
      description="Get AI-powered feedback and follow-up questions for a client's asylum declaration."
      icon={PencilSquareIcon}
    >
      <div className="flex items-start gap-3 bg-blue-50 dark:bg-blue-900/40 p-4 rounded-lg mb-6 border border-blue-200 dark:border-blue-800">
        <LightBulbIcon className="w-8 h-8 text-blue-500 dark:text-blue-400 flex-shrink-0 mt-1" />
        <div>
          <h3 className="font-semibold text-blue-800 dark:text-blue-200">Constructive Feedback</h3>
          <p className="text-sm text-blue-600 dark:text-blue-300">
            This tool reviews a declaration and provides guiding questions to help your client add the specific, vivid details that build a credible and compelling case for the judge.
          </p>
        </div>
      </div>
      <form onSubmit={handleSubmit}>
        <AutoGrowingTextarea
          value={declaration}
          onChange={(e) => setDeclaration(e.target.value)}
          placeholder="Paste the full text of the client's draft personal declaration here..."
          className="w-full min-h-[15rem] p-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !declaration.trim()}
          className="mt-4 w-full flex items-center justify-center gap-2 bg-indigo-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-indigo-700 disabled:bg-indigo-300 dark:disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors shadow"
        >
          <PaperAirplaneIcon className="w-5 h-5"/>
          Get Feedback
        </button>
      </form>
      {isLoading && <LoadingSpinner />}
      {error && <div className="mt-4 text-center text-red-500 bg-red-100 dark:bg-red-900/50 p-3 rounded-lg">{error}</div>}
      {result && (
        <div className="mt-6 prose prose-slate dark:prose-invert max-w-none prose-p:my-2 prose-headings:my-3">
          <div dangerouslySetInnerHTML={{ __html: (window as any).marked.parse(result.text) }} />
          <GroundingSources metadata={result.groundingMetadata} />
        </div>
      )}
    </ToolContainer>
  );
};

export default DeclarationFeedbackAssistant;