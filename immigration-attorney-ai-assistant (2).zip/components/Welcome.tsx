
import React from 'react';
import { SparklesIcon } from './Icons';

export const Welcome: React.FC = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full text-center">
            <SparklesIcon className="w-24 h-24 text-indigo-400 mb-6"/>
            <h1 className="text-4xl font-bold text-slate-800 dark:text-slate-100 mb-2">Immigration Attorney AI Assistant</h1>
            <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl">
                Welcome to your AI-powered workflow automator. Select a tool from the sidebar to get started. Summarize case files, draft client forms, research complex legal queries, and more.
            </p>
        </div>
    );
};
