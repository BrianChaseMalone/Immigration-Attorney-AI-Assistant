
import React from 'react';
import { ToolContainer } from './ToolContainer';
import { UserGroupIcon } from './Icons';

const ClientProfileManager: React.FC = () => {
  return (
    <ToolContainer
      title="Client Profile Manager"
      description="View and manage your client profiles."
      icon={UserGroupIcon}
    >
      <div className="text-center p-8 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-lg">
        <h3 className="text-xl font-semibold text-slate-700 dark:text-slate-200">Feature Coming Soon!</h3>
        <p className="text-slate-500 dark:text-slate-400 mt-2">
          This section will allow you to manage client profiles, link generated documents, and track case progress.
        </p>
      </div>
    </ToolContainer>
  );
};

export default ClientProfileManager;
