
import React, { useState } from 'react';
import { ToolContainer } from './ToolContainer';
import { GlobeAltIcon, PaperAirplaneIcon } from './Icons';
import { getVisaInfo, GeminiResult } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import { GroundingSources } from './GroundingSources';

const VisaInfoHub: React.FC = () => {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<GeminiResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setResult(null);
    setError(null);

    try {
      const response = await getVisaInfo(query);
      setResult(response);
    } catch (err) {
      setError('An error occurred while fetching visa information. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ToolContainer
      title="Visa Information Hub"
      description="Get up-to-date answers on visa requirements, processing times, and policy changes."
      icon={GlobeAltIcon}
    >
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="e.g., 'Current processing time for I-130 petitions at the California Service Center'"
          className="flex-grow p-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !query.trim()}
          className="flex items-center justify-center gap-2 bg-indigo-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-indigo-700 disabled:bg-indigo-300 dark:disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors shadow flex-shrink-0"
        >
           <PaperAirplaneIcon className="w-5 h-5"/>
          Search
        </button>
      </form>
      {isLoading && <LoadingSpinner />}
      {error && <div className="mt-4 text-center text-red-500 bg-red-100 dark:bg-red-900/50 p-3 rounded-lg">{error}</div>}
      {result && (
        <div className="mt-6 prose prose-slate dark:prose-invert max-w-none prose-p:my-2 prose-headings:my-3">
          <div dangerouslySetInnerHTML={{ __html: (window as any).marked.parse(result.text) }} />
          <GroundingSources metadata={result.groundingMetadata} />
        </div>
      )}
    </ToolContainer>
  );
};

export default VisaInfoHub;
