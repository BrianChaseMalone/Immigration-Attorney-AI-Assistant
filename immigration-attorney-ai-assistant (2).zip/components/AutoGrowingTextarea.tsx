import React, { useRef, useLayoutEffect, TextareaHTMLAttributes } from 'react';

type AutoGrowingTextareaProps = TextareaHTMLAttributes<HTMLTextAreaElement>;

const AutoGrowingTextarea: React.FC<AutoGrowingTextareaProps> = (props) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useLayoutEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      // Temporarily shrink to get the true scrollHeight
      textarea.style.height = 'inherit';
      const scrollHeight = textarea.scrollHeight;
      // Set the height to the scrollHeight to fit the content
      textarea.style.height = `${scrollHeight}px`;
    }
  }, [props.value]);

  return (
    <textarea
      ref={textareaRef}
      rows={1} // Start with a single row
      {...props}
      className={`${props.className} overflow-y-hidden resize-none`} // Disable manual resize and hide scrollbar
    />
  );
};

export default AutoGrowingTextarea;