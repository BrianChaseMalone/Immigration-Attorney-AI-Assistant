import React, { useState } from 'react';
import { ToolContainer } from './ToolContainer';
import { ScaleIcon, LightBulbIcon, PaperAirplaneIcon } from './Icons';
import { performLegalResearch, GeminiResult } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import { GroundingSources } from './GroundingSources';
import AutoGrowingTextarea from './AutoGrowingTextarea';

const LegalResearchAssistant: React.FC = () => {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<GeminiResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setResult(null);
    setError(null);

    try {
      const response = await performLegalResearch(query);
      setResult(response);
    } catch (err) {
      setError('An error occurred during legal research. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ToolContainer
      title="Legal Research Assistant"
      description="Leverage advanced AI for in-depth analysis of complex legal questions."
      icon={ScaleIcon}
    >
        <div className="flex items-start gap-3 bg-blue-50 dark:bg-blue-900/40 p-4 rounded-lg mb-6 border border-blue-200 dark:border-blue-800">
            <LightBulbIcon className="w-8 h-8 text-blue-500 dark:text-blue-400 flex-shrink-0 mt-1" />
            <div>
                <h3 className="font-semibold text-blue-800 dark:text-blue-200">Thinking Mode Enabled</h3>
                <p className="text-sm text-blue-600 dark:text-blue-300">
                    This tool uses a more powerful model for deep reasoning. Responses may take longer but will be more comprehensive.
                </p>
            </div>
        </div>
      <form onSubmit={handleSubmit}>
        <AutoGrowingTextarea
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Enter your complex legal query here. For example: 'Analyze the 'material support' bar to asylum in the context of duress for a client from a conflict zone, citing recent BIA decisions...'"
          className="w-full min-h-[10rem] p-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !query.trim()}
          className="mt-4 w-full flex items-center justify-center gap-2 bg-indigo-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-indigo-700 disabled:bg-indigo-300 dark:disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors shadow"
        >
          <PaperAirplaneIcon className="w-5 h-5"/>
          Begin Research
        </button>
      </form>
      {isLoading && <LoadingSpinner />}
      {error && <div className="mt-4 text-center text-red-500 bg-red-100 dark:bg-red-900/50 p-3 rounded-lg">{error}</div>}
      {result && (
        <div className="mt-6 prose prose-slate dark:prose-invert max-w-none prose-p:my-2 prose-headings:my-3">
          <div dangerouslySetInnerHTML={{ __html: (window as any).marked.parse(result.text) }} />
          <GroundingSources metadata={result.groundingMetadata} />
        </div>
      )}
    </ToolContainer>
  );
};

export default LegalResearchAssistant;