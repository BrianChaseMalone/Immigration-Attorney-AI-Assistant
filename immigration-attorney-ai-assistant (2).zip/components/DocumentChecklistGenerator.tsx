import React, { useState, useEffect } from 'react';
import { ToolContainer } from './ToolContainer';
import { ClipboardDocumentCheckIcon, PaperAirplaneIcon } from './Icons';
import { generateDocumentChecklist, GeminiResult } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import { GroundingSources } from './GroundingSources';
import AutoGrowingTextarea from './AutoGrowingTextarea';

const DocumentChecklistGenerator: React.FC = () => {
  const [caseType, setCaseType] = useState('');
  const [result, setResult] = useState<GeminiResult | null>(null);
  const [editableChecklist, setEditableChecklist] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (result) {
      setEditableChecklist(result.text);
    }
  }, [result]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!caseType.trim()) return;

    setIsLoading(true);
    setResult(null);
    setError(null);
    setEditableChecklist('');

    try {
      const response = await generateDocumentChecklist(caseType);
      setResult(response);
    } catch (err) {
      setError('An error occurred while generating the checklist. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ToolContainer
      title="Document Checklist Generator"
      description="Instantly create a comprehensive and customizable document checklist for any case type."
      icon={ClipboardDocumentCheckIcon}
    >
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
        <input
          type="text"
          value={caseType}
          onChange={(e) => setCaseType(e.target.value)}
          placeholder="e.g., K-1 Fiancé(e) Visa, VAWA Self-Petition"
          className="flex-grow p-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !caseType.trim()}
          className="flex items-center justify-center gap-2 bg-indigo-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-indigo-700 disabled:bg-indigo-300 dark:disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors shadow flex-shrink-0"
        >
           <PaperAirplaneIcon className="w-5 h-5"/>
          Generate Checklist
        </button>
      </form>
      {isLoading && <LoadingSpinner />}
      {error && <div className="mt-4 text-center text-red-500 bg-red-100 dark:bg-red-900/50 p-3 rounded-lg">{error}</div>}
      {result && (
        <div className="mt-6">
            <h3 className="text-lg font-semibold mb-2">Customizable Checklist</h3>
            <AutoGrowingTextarea
                value={editableChecklist}
                onChange={(e) => setEditableChecklist(e.target.value)}
                className="w-full min-h-[20rem] p-3 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition"
            />

            <h3 className="text-lg font-semibold mt-6 mb-2">Checklist Preview</h3>
            <div className="prose prose-slate dark:prose-invert max-w-none prose-p:my-2 prose-headings:my-3 prose-li:my-1 p-4 border border-slate-200 dark:border-slate-700 rounded-lg">
                <div dangerouslySetInnerHTML={{ __html: (window as any).marked.parse(editableChecklist) }} />
            </div>
            <GroundingSources metadata={result.groundingMetadata} />
        </div>
      )}
    </ToolContainer>
  );
};

export default DocumentChecklistGenerator;