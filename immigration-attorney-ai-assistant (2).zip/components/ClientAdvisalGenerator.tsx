import React, { useState } from 'react';
import { ToolContainer } from './ToolContainer';
import { ChatBubbleBottomCenterTextIcon, PaperAirplaneIcon } from './Icons';
import { generateClientAdvisal, GeminiResult } from '../services/geminiService';
import { LoadingSpinner } from './LoadingSpinner';
import { GroundingSources } from './GroundingSources';
import AutoGrowingTextarea from './AutoGrowingTextarea';

const ClientAdvisalGenerator: React.FC = () => {
  const [details, setDetails] = useState({
    clientName: '',
    caseType: '',
    currentStage: '',
    nextStage: '',
    deadlines: '',
    concerns: '',
  });
  const [result, setResult] = useState<GeminiResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setDetails(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!details.caseType.trim() || !details.currentStage.trim() || !details.nextStage.trim()) return;

    setIsLoading(true);
    setResult(null);
    setError(null);

    try {
      const response = await generateClientAdvisal(details);
      setResult(response);
    } catch (err) {
      setError('An error occurred while generating the advisal. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };
  
  const isFormIncomplete = !details.caseType.trim() || !details.currentStage.trim() || !details.nextStage.trim();

  return (
    <ToolContainer
      title="Client Advisal Generator"
      description="Draft personalized case status updates and advisals for your clients."
      icon={ChatBubbleBottomCenterTextIcon}
    >
      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="md:col-span-2">
          <label htmlFor="clientName" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Client Name (Optional)</label>
          <input type="text" name="clientName" id="clientName" value={details.clientName} onChange={handleChange} placeholder="e.g., Jane Doe" className="w-full p-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition" disabled={isLoading} />
        </div>
        <div>
          <label htmlFor="caseType" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Case Type *</label>
          <input type="text" name="caseType" id="caseType" value={details.caseType} onChange={handleChange} placeholder="e.g., I-485 Adjustment of Status" required className="w-full p-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition" disabled={isLoading} />
        </div>
        <div>
          <label htmlFor="currentStage" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Current Case Stage *</label>
          <input type="text" name="currentStage" id="currentStage" value={details.currentStage} onChange={handleChange} placeholder="e.g., Awaiting biometrics notice" required className="w-full p-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition" disabled={isLoading} />
        </div>
        <div className="md:col-span-2">
          <label htmlFor="nextStage" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Next Immediate Stage *</label>
          <input type="text" name="nextStage" id="nextStage" value={details.nextStage} onChange={handleChange} placeholder="e.g., Attend biometrics appointment" required className="w-full p-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition" disabled={isLoading} />
        </div>
        <div className="md:col-span-2">
          <label htmlFor="deadlines" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Important Dates / Deadlines</label>
          <AutoGrowingTextarea name="deadlines" id="deadlines" value={details.deadlines} onChange={handleChange} placeholder="e.g., Respond to RFE by 10/15/2024" className="w-full min-h-[6rem] p-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition" disabled={isLoading}></AutoGrowingTextarea>
        </div>
        <div className="md:col-span-2">
          <label htmlFor="concerns" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Specific Client Concerns to Address</label>
          <AutoGrowingTextarea name="concerns" id="concerns" value={details.concerns} onChange={handleChange} placeholder="e.g., Client is worried about the interview process." className="w-full min-h-[6rem] p-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-700 focus:ring-2 focus:ring-indigo-500 focus:outline-none transition" disabled={isLoading}></AutoGrowingTextarea>
        </div>
        <div className="md:col-span-2">
          <button
            type="submit"
            disabled={isLoading || isFormIncomplete}
            className="mt-2 w-full flex items-center justify-center gap-2 bg-indigo-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-indigo-700 disabled:bg-indigo-300 dark:disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors shadow"
          >
            <PaperAirplaneIcon className="w-5 h-5"/>
            Generate Advisal
          </button>
        </div>
      </form>
      {isLoading && <LoadingSpinner />}
      {error && <div className="mt-4 text-center text-red-500 bg-red-100 dark:bg-red-900/50 p-3 rounded-lg">{error}</div>}
      {result && (
        <div className="mt-6 prose prose-slate dark:prose-invert max-w-none prose-p:my-2 prose-headings:my-3">
          <div dangerouslySetInnerHTML={{ __html: (window as any).marked.parse(result.text) }} />
          <GroundingSources metadata={result.groundingMetadata} />
        </div>
      )}
    </ToolContainer>
  );
};

export default ClientAdvisalGenerator;