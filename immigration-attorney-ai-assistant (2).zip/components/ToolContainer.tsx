
import React, { ReactNode } from 'react';

interface ToolContainerProps {
  title: string;
  description: string;
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
  children: ReactNode;
}

export const ToolContainer: React.FC<ToolContainerProps> = ({ title, description, icon: Icon, children }) => {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center gap-4 mb-6">
        <div className="bg-indigo-100 dark:bg-indigo-900/50 p-3 rounded-lg">
            <Icon className="w-8 h-8 text-indigo-600 dark:text-indigo-400" />
        </div>
        <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-800 dark:text-slate-100">{title}</h2>
            <p className="text-slate-500 dark:text-slate-400 mt-1">{description}</p>
        </div>
      </div>
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg">
        {children}
      </div>
    </div>
  );
};
