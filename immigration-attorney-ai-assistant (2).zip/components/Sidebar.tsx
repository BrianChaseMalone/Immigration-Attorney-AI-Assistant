
import React from 'react';
import { TOOLS } from '../constants';
import { ToolId } from '../types';
import { SparklesIcon } from './Icons';

interface SidebarProps {
  activeTool: ToolId | null;
  onSelectTool: (toolId: ToolId) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTool, onSelectTool }) => {
  return (
    <aside className="bg-slate-50 dark:bg-slate-900 w-64 p-4 border-r border-slate-200 dark:border-slate-800 flex flex-col">
      <div className="flex items-center gap-2 mb-8">
        <SparklesIcon className="w-8 h-8 text-indigo-500" />
        <h1 className="text-xl font-bold text-slate-800 dark:text-slate-100">AI Assistant</h1>
      </div>
      <nav>
        <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">Tools</p>
        <ul>
          {TOOLS.map((tool) => (
            <li key={tool.id}>
              <button
                onClick={() => onSelectTool(tool.id)}
                className={`w-full flex items-center gap-3 text-left p-2 rounded-lg transition-colors ${
                  activeTool === tool.id
                    ? 'bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <tool.icon className="w-5 h-5 flex-shrink-0" />
                <span className="text-sm font-medium">{tool.name}</span>
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};
