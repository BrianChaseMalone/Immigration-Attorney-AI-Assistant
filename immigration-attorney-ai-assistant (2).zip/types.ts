export interface GroundingChunk {
  web?: {
    uri: string;
    title?: string;
  };
  maps?: {
    uri: string;
    title?: string;
  };
}

export interface GroundingMetadata {
  groundingChunks: GroundingChunk[];
}

export type ToolId =
  | 'summarizer'
  | 'intake-form-drafter'
  | 'visa-info-hub'
  | 'legal-research'
  | 'local-services'
  | 'client-advisal'
  | 'doc-checklist'
  | 'corroborating-evidence-advisor'
  | 'declaration-feedback-assistant'
  | 'collaborative-response-generator';